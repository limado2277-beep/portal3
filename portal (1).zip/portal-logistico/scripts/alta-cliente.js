'use strict';
// Alta de una empresa nueva: una instancia propia (puerto, carpeta de datos y copias, administrador) en minutos.
// Uso:  node scripts/alta-cliente.js --nombre "Pyme SA" --dominio portal.pymesa.com.ar --admin dueno@pymesa.com.ar [--slug pymesa] [--port 4001]
//       node scripts/alta-cliente.js --listar
// Después:  npm run clientes   (levanta todas) y poné el Caddyfile generado (clientes/Caddyfile) delante.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const root = path.resolve(process.env.CLIENTES_DIR || path.join(__dirname, '..', 'clientes'));
const idx = path.join(root, 'clientes.json');
const arg = k => { const i = process.argv.indexOf('--' + k); return i > 0 ? process.argv[i + 1] : undefined; };
const slugify = s => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 30);
const load = () => { try { return JSON.parse(fs.readFileSync(idx, 'utf8')); } catch (_) { return []; } };
const die = m => { console.error('Error: ' + m); process.exit(1); };

function caddy(list) {
  return list.map(c => `${c.dominio} {\n\tencode gzip\n\treverse_proxy 127.0.0.1:${c.port}\n}\n`).join('\n');
}
function clavePropia() { // 20 caracteres sin ambigüedades
  const abc = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789', b = crypto.randomBytes(20);
  return Array.from(b, x => abc[x % abc.length]).join('');
}

function alta({ nombre, dominio, admin, slug, port }) {
  if (!nombre || !dominio || !admin) die('Faltan datos: --nombre, --dominio y --admin son obligatorios.');
  if (!/^[a-z0-9]([a-z0-9.-]*[a-z0-9])?\.[a-z]{2,}$/i.test(dominio)) die('El dominio no es válido.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(admin)) die('El correo del administrador no es válido.');
  slug = slug ? slugify(slug) : slugify(nombre);
  if (!slug) die('No se pudo armar un identificador: usá --slug.');
  const list = load();
  if (list.some(c => c.slug === slug)) die('Ya existe un cliente con el identificador "' + slug + '".');
  if (list.some(c => c.dominio.toLowerCase() === dominio.toLowerCase())) die('Ese dominio ya está asignado.');
  port = port ? parseInt(port, 10) : Math.max(4000, ...list.map(c => c.port)) + 1;
  if (!(port > 1024 && port < 65536) || list.some(c => c.port === port)) die('Puerto no válido o repetido.');
  const dir = path.join(root, slug), password = clavePropia();
  fs.mkdirSync(path.join(dir, 'data'), { recursive: true });
  fs.mkdirSync(path.join(dir, 'backups'), { recursive: true });
  const env = [
    `COMPANY_NAME=${nombre.replace(/[\r\n]/g, ' ')}`, `PORT=${port}`, `BASE_URL=https://${dominio}`, 'TRUST_PROXY=1',
    `DATA_DIR=${path.join(dir, 'data')}`, `BACKUP_DIR=${path.join(dir, 'backups')}`, 'BACKUP_KEEP=14',
    `ADMIN_EMAIL=${admin}`, `ADMIN_PASSWORD=${password}`, ''].join('\n');
  fs.writeFileSync(path.join(dir, '.env'), env, { mode: 0o600 });
  list.push({ slug, nombre, dominio, port, admin, creado: new Date().toISOString().slice(0, 10) });
  fs.writeFileSync(idx, JSON.stringify(list, null, 2));
  fs.writeFileSync(path.join(root, 'Caddyfile'), caddy(list));
  console.log(`\nCliente creado: ${nombre}\n  Identificador: ${slug}\n  Dirección:     https://${dominio}  (puerto interno ${port})\n  Administrador: ${admin}\n  Clave inicial: ${password}\n\nAnotá la clave ahora: queda en clientes/${slug}/.env (solo lectura para tu usuario) y se muestra una sola vez.\nPasos: 1) apuntá el DNS de ${dominio} a este servidor  2) npm run clientes (o enviá SIGHUP si ya está corriendo)  3) recargá Caddy con clientes/Caddyfile  4) entrá, cambiá la clave y activá la verificación en dos pasos.\n`);
  return { slug, port, password };
}

if (require.main === module) {
  if (process.argv.includes('--listar')) {
    const l = load(); if (!l.length) console.log('No hay clientes.'); else l.forEach(c => console.log(`${c.slug.padEnd(20)} ${String(c.port).padEnd(6)} ${c.dominio}  (${c.nombre})`));
  } else alta({ nombre: arg('nombre'), dominio: arg('dominio'), admin: arg('admin'), slug: arg('slug'), port: arg('port') });
}
module.exports = { alta, caddy };
