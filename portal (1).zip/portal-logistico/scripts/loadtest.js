'use strict';
// Prueba de carga local: levanta el servidor en una carpeta temporal, carga datos y simula usuarios a la vez.
// Uso: npm run loadtest [usuarios=40] [segundos=20] [entregas=3000]
const os = require('node:os'), fs = require('node:fs'), path = require('node:path');
const { createServer } = require('../server');
const { open, setDoc } = require('../lib/db');
const U = +process.argv[2] || 40, SEC = +process.argv[3] || 20, N = +process.argv[4] || 3000;
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'carga-'));
const { server } = createServer({ port: 0, dataDir: dir, companyName: 'Carga', adminEmail: 'a@c.com', adminPassword: 'clave-admin-123', cookieSecure: false, trustProxy: false, quiet: true, rateLimit: 1e9 });  // en la prueba todos salen de la misma IP; en producción cada uno tiene la suya
server.listen(0, async () => {
  const base = 'http://127.0.0.1:' + server.address().port;
  const mk = () => { let sid = ''; return async (m, u, b) => { const t0 = performance.now(); const r = await fetch(base + u, { method: m, headers: { cookie: sid ? 'sid=' + sid : '', 'content-type': 'application/json' }, body: b === undefined ? undefined : JSON.stringify(b) }); const c = r.headers.get('set-cookie'), mm = c && c.match(/sid=([a-f0-9]{64})/); if (mm) sid = mm[1]; let j = null; try { j = await r.json(); } catch (_) {} return { s: r.status, j, ms: performance.now() - t0 }; }; };
  const admin = mk(); await admin('POST', '/api/login', { email: 'a@c.com', password: 'clave-admin-123' });
  const choferes = [], clientes = [];
  for (let i = 0; i < U; i++) { const ch = i % 4 !== 0, r = await admin('POST', '/api/users', { email: `u${i}@c.com`, name: (ch ? 'Chofer ' : 'Cliente ') + i, role: ch ? 'chofer' : 'cliente', password: 'clave-larga-' + i }); (ch ? choferes : clientes).push({ id: r.j.id, email: `u${i}@c.com`, pass: 'clave-larga-' + i }); }
  const t0 = performance.now(), db2 = open(path.join(dir, 'portal.db'));
  db2.exec('BEGIN');
  for (let i = 0; i < N; i++) {
    const ch = choferes[i % choferes.length], cl = clientes[i % clientes.length], id = 'e' + i, e = { id, guia: 'G-' + i, clienteId: cl.id, cliente: 'c', choferId: ch.id, chofer: 'c', fecha: '2026-11-12', desde: '08:00', hasta: '18:00', direccion: 'Calle ' + i, estado: 'programada', orden: i % 30 };
    setDoc(db2, 'entregas/' + id, e); setDoc(db2, `portal/${cl.id}/entregas/${id}`, e);
  }
  db2.exec('COMMIT'); db2.close();
  console.log(`Cargadas ${N} entregas en ${((performance.now() - t0) / 1000).toFixed(1)} s`);
  const sess = []; for (const u of choferes.concat(clientes)) { const f = mk(); const r = await f('POST', '/api/login', { email: u.email, password: u.pass }); if (r.s === 200) sess.push({ f, u, ch: choferes.includes(u) }); }
  const lat = { lectura: [], escritura: [] }; let err = 0, ops = 0, stop = performance.now() + SEC * 1000;
  await Promise.all(sess.map(async (s, k) => {
    while (performance.now() < stop) {
      const r = s.ch ? await s.f('GET', '/api/col?path=entregas&where=' + encodeURIComponent(JSON.stringify([['choferId', '==', s.u.id]]))) : await s.f('GET', '/api/col?path=' + encodeURIComponent(`portal/${s.u.id}/entregas`));
      lat.lectura.push(r.ms); ops++; if (r.s !== 200) err++;
      if (s.ch && r.j && r.j.length) { const d = r.j[(Math.random() * r.j.length) | 0], w = await s.f('PUT', '/api/doc?path=' + encodeURIComponent('entregas/' + d.id), Object.assign({}, d.data, { estado: 'en_camino' })); lat.escritura.push(w.ms); ops++; if (w.s !== 200) err++; }
      await new Promise(r => setTimeout(r, 800 + Math.random() * 400));   // un usuario real consulta cada ~5 s; acá es más exigente
    }
  }));
  const pc = (a, p) => a.length ? a.slice().sort((x, y) => x - y)[Math.min(a.length - 1, Math.floor(a.length * p))].toFixed(0) : '-';
  console.log(`${sess.length} usuarios conectados, ${SEC} s, ${ops} operaciones (${(ops / SEC).toFixed(0)}/s), errores: ${err}`);
  for (const k of ['lectura', 'escritura']) console.log(`  ${k}: ${lat[k].length} · mediana ${pc(lat[k], .5)} ms · p95 ${pc(lat[k], .95)} ms · p99 ${pc(lat[k], .99)} ms`);
  console.log('Tamaño de la base:', (fs.statSync(path.join(dir, 'portal.db')).size / 1048576).toFixed(1), 'MB');
  server.close(); fs.rmSync(dir, { recursive: true, force: true }); process.exit(err ? 1 : 0);
});
