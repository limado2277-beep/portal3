'use strict';
// Prueba de humo: ingreso, permisos por rol y aislamiento entre clientes.
const os = require('node:os'), fs = require('node:fs'), path = require('node:path'), assert = require('node:assert');
const { createServer } = require('../server');
let TCFG;

const net = require('node:net');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'portal-'));

// Servidor SMTP falso: guarda los correos que el portal intenta enviar.
const mails = [];
const smtp = net.createServer(sock => {
  let data = false, buf = '', cur = { to: '', raw: '' };
  sock.write('220 falso listo\r\n');
  sock.on('data', d => {
    buf += d.toString('utf8');
    for (;;) {
      if (data) { const i = buf.indexOf('\r\n.\r\n'); if (i < 0) return; cur.raw = buf.slice(0, i); buf = buf.slice(i + 5); data = false; mails.push(cur); cur = { to: '', raw: '' }; sock.write('250 en cola\r\n'); continue; }
      const i = buf.indexOf('\r\n'); if (i < 0) return;
      const line = buf.slice(0, i); buf = buf.slice(i + 2);
      if (/^EHLO/i.test(line)) sock.write('250 hola\r\n');
      else if (/^MAIL/i.test(line)) sock.write('250 ok\r\n');
      else if (/^RCPT/i.test(line)) { cur.to = line.match(/<(.*)>/)[1]; sock.write('250 ok\r\n'); }
      else if (/^DATA/i.test(line)) { data = true; sock.write('354 sigue\r\n'); }
      else if (/^QUIT/i.test(line)) { sock.write('221 chau\r\n'); sock.end(); return; }
      else sock.write('500 no\r\n');
    }
  });
  sock.on('error', () => {});
});
const decode = m => { const parts = m.raw.split('\r\n\r\n'); const hdr = parts[0]; const body = Buffer.from(parts.slice(1).join('').replace(/\s/g, ''), 'base64').toString('utf8'); const sub = (hdr.match(/Subject: (.*)/) || [])[1] || ''; const mm = sub.match(/=\?UTF-8\?B\?(.*)\?=/); return { to: m.to, subject: mm ? Buffer.from(mm[1], 'base64').toString('utf8') : sub, body }; };
const hooks = [];
const hookSrv = require('node:http').createServer((rq, rs) => { let b = ''; rq.on('data', d => b += d); rq.on('end', () => { hooks.push({ body: b, sig: rq.headers['x-signature'] }); rs.end('ok'); }); });
hookSrv.listen(0, '127.0.0.1');
let server;
let pass = 0;
const t = async (name, fn) => { try { await fn(); pass++; console.log('  ok  ' + name); } catch (e) { console.log('FALLA ' + name + '\n      ' + e.message); process.exitCode = 1; } };

smtp.listen(0, '127.0.0.1', () => {
  TCFG = { port: 0, dataDir: dir, companyName: 'Empresa Test', adminEmail: 'admin@test.com', adminPassword: 'clave-admin-123', cookieSecure: false, trustProxy: false, quiet: true, baseUrl: 'https://portal.test', integrationKey: 'clave-de-integracion-de-prueba-123', webhookUrl: () => 'http://127.0.0.1:' + hookSrv.address().port + '/hook', webhookSecret: 'secreto-de-prueba-largo-1', smtp: { host: '127.0.0.1', port: smtp.address().port, secure: 'none', from: 'Empresa Test <no-reply@test.com>', retryDelays: [0] } }; server = createServer(TCFG).server;
  server.listen(0, run);
});
async function run() {
  const base = 'http://127.0.0.1:' + server.address().port;
  const mk = () => { let sid = ''; return async (m, u, body, hdr) => {
    const r = await fetch(base + u, { method: m, headers: Object.assign({ cookie: sid ? 'sid=' + sid : '', ...(body !== undefined ? { 'content-type': 'application/json' } : {}) }, hdr || {}), body: body === undefined ? undefined : JSON.stringify(body) });
    const c = r.headers.get('set-cookie'); const mm = c && c.match(/sid=([a-f0-9]{64})/); if (mm) sid = mm[1];
    let j = null; try { j = await r.json(); } catch (_) {} return { s: r.status, j }; }; };
  const admin = mk(), c1 = mk(), c2 = mk(), ch1 = mk(), ch2 = mk(), anon = mk();

  await t('sin sesión no entra', async () => { assert.equal((await anon('GET', '/api/me')).s, 401); assert.equal((await anon('GET', '/api/col?path=entregas')).s, 401); });
  await t('clave incorrecta rechazada', async () => assert.equal((await anon('POST', '/api/login', { email: 'admin@test.com', password: 'mala' })).s, 401));
  await t('admin ingresa', async () => { const r = await admin('POST', '/api/login', { email: 'admin@test.com', password: 'clave-admin-123' }); assert.equal(r.s, 200); assert.equal(r.j.role, 'admin'); });

  const ids = {};
  for (const [k, e, n, r] of [['c1', 'c1@t.com', 'Cliente Uno', 'cliente'], ['c2', 'c2@t.com', 'Cliente Dos', 'cliente'], ['d1', 'd1@t.com', 'Chofer Uno', 'chofer'], ['d2', 'd2@t.com', 'Chofer Dos', 'chofer']]) {
    await t('crear usuario ' + k, async () => { const x = await admin('POST', '/api/users', { email: e, name: n, role: r, password: 'clave-larga-' + k }); assert.equal(x.s, 200); ids[k] = x.j.id; });
  }
  await t('clave corta rechazada', async () => assert.equal((await admin('POST', '/api/users', { email: 'x@t.com', name: 'X', role: 'cliente', password: 'corta' })).s, 400));
  await t('crea perfiles automáticamente', async () => { const r = await admin('GET', '/api/doc?path=' + encodeURIComponent('perfiles/' + ids.c1)); assert.equal(r.j.data.rol, 'cliente'); });
  for (const [k, fn] of [['c1', c1], ['c2', c2], ['d1', ch1], ['d2', ch2]]) await fn('POST', '/api/login', { email: k + '@t.com', password: 'clave-larga-' + k });

  const put = (fn, p, d) => fn('PUT', '/api/doc?path=' + encodeURIComponent(p), d);
  const E = (id, cli, cho) => ({ id, guia: 'G-' + id, clienteId: ids[cli], cliente: cli, choferId: ids[cho], estado: 'programada' });
  await t('admin carga entregas (principal y copia del cliente)', async () => {
    for (const [id, cli, cho] of [['e1', 'c1', 'd1'], ['e2', 'c2', 'd1'], ['e3', 'c2', 'd2']]) {
      assert.equal((await put(admin, 'entregas/' + id, E(id, cli, cho))).s, 200);
      assert.equal((await put(admin, `portal/${ids[cli]}/entregas/${id}`, E(id, cli, cho))).s, 200);
    }
  });
  const list = async (fn, p, w) => (await fn('GET', '/api/col?path=' + encodeURIComponent(p) + (w ? '&where=' + encodeURIComponent(JSON.stringify(w)) : ''))).j;

  await t('cliente ve solo lo suyo', async () => {
    const a = await list(c1, `portal/${ids.c1}/entregas`); assert.deepEqual(a.map(x => x.id), ['e1']);
    const b = await list(c2, `portal/${ids.c2}/entregas`); assert.deepEqual(b.map(x => x.id).sort(), ['e2', 'e3']);
  });
  await t('cliente NO ve lo de otro cliente', async () => assert.equal((await c1('GET', '/api/col?path=' + encodeURIComponent(`portal/${ids.c2}/entregas`))).s, 403));
  await t('cliente NO ve la lista general ni viajes ni depósito', async () => {
    for (const p of ['entregas', 'viajes', 'wms/skus/items', 'perfiles', 'portal']) assert.equal((await c1('GET', '/api/col?path=' + encodeURIComponent(p))).s, 403, p);
  });
  await t('cliente NO puede escribir', async () => {
    assert.equal((await put(c1, `portal/${ids.c1}/entregas/e1`, { estado: 'entregada' })).s, 403);
    assert.equal((await put(c1, 'entregas/e1', { estado: 'entregada' })).s, 403);
  });
  await t('cliente NO puede leer documento ajeno directo', async () => assert.equal((await c1('GET', '/api/doc?path=' + encodeURIComponent(`portal/${ids.c2}/entregas/e2`))).s, 403));
  await t('chofer ve solo sus entregas', async () => {
    assert.deepEqual((await list(ch1, 'entregas', [['choferId', '==', ids.d1]])).map(x => x.id).sort(), ['e1', 'e2']);
    assert.deepEqual((await list(ch1, 'entregas')).map(x => x.id).sort(), ['e1', 'e2']);   // aunque no filtre
    assert.deepEqual((await list(ch2, 'entregas')).map(x => x.id), ['e3']);
  });
  await t('chofer actualiza estado de lo suyo (principal y copia del cliente)', async () => {
    assert.equal((await put(ch1, 'entregas/e1', Object.assign(E('e1', 'c1', 'd1'), { estado: 'en_camino' }))).s, 200);
    assert.equal((await put(ch1, `portal/${ids.c1}/entregas/e1`, Object.assign(E('e1', 'c1', 'd1'), { estado: 'en_camino' }))).s, 200);
    assert.equal((await list(c1, `portal/${ids.c1}/entregas`))[0].data.estado, 'en_camino');
  });
  await t('chofer NO toca entregas de otro chofer', async () => {
    assert.equal((await put(ch1, 'entregas/e3', Object.assign(E('e3', 'c2', 'd2'), { estado: 'entregada' }))).s, 403);
    assert.equal((await put(ch1, `portal/${ids.c2}/entregas/e3`, Object.assign(E('e3', 'c2', 'd2'), { estado: 'entregada' }))).s, 403);
  });
  await t('chofer NO puede reasignarse una entrega ajena ni crear nuevas ni borrar', async () => {
    assert.equal((await put(ch1, 'entregas/e3', E('e3', 'c2', 'd1'))).s, 403);
    assert.equal((await put(ch1, 'entregas/nueva', E('nueva', 'c1', 'd1'))).s, 403);
    assert.equal((await ch1('DELETE', '/api/doc?path=' + encodeURIComponent('entregas/e1'))).s, 403);
  });
  await t('cada usuario lee su propio perfil y la configuración que le corresponde', async () => {
    assert.equal((await c1('GET', '/api/doc?path=' + encodeURIComponent('perfiles/' + ids.c1))).j.data.rol, 'cliente');
    assert.equal((await c1('GET', '/api/doc?path=' + encodeURIComponent('perfiles/' + ids.d1))).s, 403);
    assert.equal((await put(admin, 'config/deposito', { lat: -34.6, lng: -58.4 })).s, 200);
    assert.equal((await ch1('GET', '/api/doc?path=config/deposito')).j.exists, true);
    assert.equal((await c1('GET', '/api/doc?path=config/deposito')).s, 403);
  });
  await t('chofer NO accede a viajes, depósito, perfiles ni usuarios', async () => {
    for (const p of ['viajes', 'wms/kardex/items', 'perfiles']) assert.equal((await ch1('GET', '/api/col?path=' + encodeURIComponent(p))).s, 403, p);
    assert.equal((await ch1('GET', '/api/users')).s, 403);
  });
  await t('solo admin escribe viajes y depósito', async () => {
    assert.equal((await put(ch1, 'viajes/G1', { km: 1 })).s, 403);
    assert.equal((await put(admin, 'viajes/G1', { km: 1 })).s, 200);
    assert.equal((await put(admin, 'wms/skus/items/P1', { codigo: 'P1' })).s, 200);
  });
  await t('consulta con filtros', async () => assert.equal((await list(admin, 'entregas', [['estado', '==', 'programada']])).length, 2));
  await t('rechaza rutas raras', async () => { assert.equal((await admin('GET', '/api/doc?path=' + encodeURIComponent('../etc/passwd'))).s, 400); assert.equal((await admin('GET', '/api/doc?path=entregas')).s, 400); });
  await t('origen cruzado bloqueado', async () => assert.equal((await admin('PUT', '/api/doc?path=entregas/x', {}, { origin: 'https://malo.example' })).s, 403));
  await t('desactivar usuario corta su sesión', async () => {
    assert.equal((await admin('PATCH', '/api/users/' + ids.c2, { active: false })).s, 200);
    assert.equal((await c2('GET', '/api/me')).s, 401);
    assert.equal((await anon('POST', '/api/login', { email: 'c2@t.com', password: 'clave-larga-c2' })).s, 401);
  });
  await t('cambio de clave cierra sesiones y sirve la nueva', async () => {
    assert.equal((await admin('PATCH', '/api/users/' + ids.c1, { password: 'otra-clave-nueva-1' })).s, 200);
    assert.equal((await c1('GET', '/api/me')).s, 401);
    assert.equal((await anon('POST', '/api/login', { email: 'c1@t.com', password: 'otra-clave-nueva-1' })).s, 200);
  });
  await t('subir PDF (admin) y descargarlo con sesión; sin sesión no', async () => {
    const r = await fetch(base + '/api/upload', { method: 'POST', headers: { cookie: 'sid=' + (await (async () => { const l = await fetch(base + '/api/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: 'admin@test.com', password: 'clave-admin-123' }) }); return l.headers.get('set-cookie').match(/sid=([a-f0-9]{64})/)[1]; })()), 'content-type': 'application/pdf', 'x-filename': 'remito.pdf' }, body: Buffer.from('%PDF-1.4 prueba') });
    const j = await r.json(); assert.equal(r.status, 200);
    assert.equal((await fetch(base + j.url)).status, 401);
  });
  await t('tipo de archivo no permitido', async () => { const l = await fetch(base + '/api/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: 'admin@test.com', password: 'clave-admin-123' }) }); const sid = l.headers.get('set-cookie').match(/sid=([a-f0-9]{64})/)[1]; const r = await fetch(base + '/api/upload', { method: 'POST', headers: { cookie: 'sid=' + sid, 'content-type': 'text/html' }, body: '<script>1</script>' }); assert.equal(r.status, 415); });
  await t('límite de intentos de ingreso', async () => { let last; for (let i = 0; i < 10; i++) last = (await anon('POST', '/api/login', { email: 'victima@t.com', password: 'x' })).s; assert.equal(last, 429); });
  await t('archivos estáticos y cabeceras de seguridad', async () => { const r = await fetch(base + '/'); assert.equal(r.status, 200); assert.ok(r.headers.get('content-security-policy')); const x = await fetch(base + '/%2e%2e/server.js'); assert.notEqual(x.status, 200); });

  // ---------- ampliaciones: depósito, equipos, check lists, archivos, auditoría, correo ----------
  const login = async (fn, e, p) => (await fn('POST', '/api/login', { email: e, password: p })).s;
  const cc1 = mk(), dep = mk();
  await login(cc1, 'c1@t.com', 'otra-clave-nueva-1');
  await t('contraseñas flojas rechazadas', async () => {
    for (const pw of ['password123', 'aaaaaaaaaaaa', 'operario.uno.2026']) assert.equal((await admin('POST', '/api/users', { email: 'operario@t.com', name: 'Op', role: 'deposito', password: pw })).s, 400, pw);
  });
  await t('crear operario de depósito', async () => {
    const x = await admin('POST', '/api/users', { email: 'o1@t.com', name: 'Operario Uno', role: 'deposito', password: 'clave-larga-o1' }); assert.equal(x.s, 200); ids.o1 = x.j.id;
    assert.equal(await login(dep, 'o1@t.com', 'clave-larga-o1'), 200);
  });
  await t('operario NO ve entregas, clientes, config, viajes ni perfiles ajenos', async () => {
    for (const p of ['entregas', 'portal', 'config', 'viajes', 'perfiles']) assert.equal((await dep('GET', '/api/col?path=' + encodeURIComponent(p))).s, 403, p);
    assert.equal((await dep('GET', '/api/doc?path=config/deposito')).s, 403);
    assert.equal((await dep('GET', '/api/doc?path=' + encodeURIComponent('perfiles/' + ids.d1))).s, 403);
    assert.equal((await dep('GET', '/api/doc?path=' + encodeURIComponent('perfiles/' + ids.o1))).s, 200);
    assert.equal((await put(dep, 'entregas/e1', E('e1', 'c1', 'd1'))).s, 403);
  });
  await t('operario de depósito opera el WMS (recepción, picking) pero chofer y cliente no', async () => {
    assert.equal((await put(dep, 'wms/ocs/items/OC1', { id: 'OC1', ref: 'OC-1', estado: 'abierta', lineas: [{ sku: 'P1', qty: 5, rec: 0 }] })).s, 200);
    assert.equal((await put(dep, 'wms/kardex/items/MX1', { id: 'MX1', tipo: 'IN', sku: 'P1', ubicacion: 'A1', in: 5, out: 0 })).s, 200);
    assert.equal((await list(dep, 'wms/ocs/items')).length, 1);
    assert.equal((await put(dep, 'wms/picks/items/PK1', { id: 'PK1', estado: 'pendiente', lineas: [] })).s, 200);
    for (const who of [ch2, cc1]) { assert.equal((await who('GET', '/api/col?path=' + encodeURIComponent('wms/ocs/items'))).s, 403); assert.equal((await put(who, 'wms/ocs/items/OCX', { id: 'OCX' })).s, 403); }
    assert.equal((await dep('GET', '/api/col?path=viajes')).s, 403);
    assert.equal((await put(dep, 'viajes/v1', { x: 1 })).s, 403);
  });
  await t('alta masiva: crea con clave temporal que sirve, informa errores por fila, solo admin', async () => {
    const r = await admin('POST', '/api/users/bulk', { users: [
      { email: 'b1@t.com', name: 'Chofer Masivo', role: 'chofer', telefono: '11 4444-0000' },
      { email: 'b2@t.com', name: 'Cliente Masivo', role: 'cliente' },
      { email: 'b1@t.com', name: 'Repetido', role: 'chofer' },
      { email: 'malo', name: 'X', role: 'chofer' },
      { email: 'b3@t.com', name: 'Jefe', role: 'admin' },
      { email: 'o1@t.com', name: 'Ya existe', role: 'deposito' }] });
    assert.equal(r.s, 200); assert.equal(r.j.creados.length, 2); assert.equal(r.j.errores.length, 4);
    assert.match(r.j.creados[0].password, /^[A-Za-z2-9]{3}(-[A-Za-z2-9]{3}){3}$/);
    const bm = mk(); assert.equal(await login(bm, 'b1@t.com', r.j.creados[0].password), 200);
    const pf = await admin('GET', '/api/doc?path=' + encodeURIComponent('perfiles/' + r.j.creados[0].id));
    assert.equal(pf.j.data.rol, 'chofer'); assert.equal(pf.j.data.telefono, '11 4444-0000');
    assert.equal((await ch2('POST', '/api/users/bulk', { users: [{ email: 'z@t.com', name: 'Z', role: 'chofer' }] })).s, 403);
    assert.equal((await admin('POST', '/api/users/bulk', { users: [] })).s, 400);
    assert.equal((await ch2('GET', '/api/onboarding')).s, 403);
    const o = await admin('GET', '/api/onboarding'); assert.equal(o.s, 200); assert.ok(o.j.usuarios.chofer >= 1); assert.equal(typeof o.j.backup.n, 'number'); assert.equal(o.j.totpAdmin, false);
  });
  await t('mapas: solo admin, valida entradas y traduce la respuesta del servicio de ruteo', async () => {
    const http = require('node:http'); let lastUrl = '';
    const osrm = http.createServer((q, r) => { lastUrl = q.url; r.setHeader('content-type', 'application/json'); if (q.url.includes('/0.000000,0.000000;')) { r.statusCode = 400; return r.end(JSON.stringify({ code: 'InvalidQuery' })); } const n = q.url.split('/table/v1/driving/')[1].split('?')[0].split(';').length; const m = f => Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => (i === j ? 0 : f * Math.abs(i - j)))); r.end(JSON.stringify({ code: 'Ok', durations: m(60), distances: m(1000) })); });
    await new Promise(r => osrm.listen(0, r)); const port = osrm.address().port;
    assert.equal((await ch1('POST', '/api/ruta/matriz', { puntos: [{ lat: -34.6, lng: -58.4 }, { lat: -34.7, lng: -58.3 }] })).s, 403);
    assert.equal((await admin('POST', '/api/ruta/matriz', { puntos: [{ lat: -34.6, lng: -58.4 }, { lat: -34.7, lng: -58.3 }] })).s, 501);   // sin ROUTING_URL
    TCFG.routingUrl = 'http://127.0.0.1:' + port;
    assert.equal((await admin('POST', '/api/ruta/matriz', { puntos: [{ lat: -34.6, lng: -58.4 }] })).s, 400);
    assert.equal((await admin('POST', '/api/ruta/matriz', { puntos: [{ lat: 999, lng: 0 }, { lat: 1, lng: 1 }] })).s, 400);
    assert.equal((await admin('POST', '/api/ruta/matriz', { puntos: Array.from({ length: 101 }, () => ({ lat: -34.6, lng: -58.4 })) })).s, 400);
    const ok = await admin('POST', '/api/ruta/matriz', { puntos: [{ lat: -34.6, lng: -58.4 }, { lat: -34.7, lng: -58.3 }, { lat: -34.8, lng: -58.2 }] });
    assert.equal(ok.s, 200); assert.equal(ok.j.durations[0][2], 120); assert.equal(ok.j.distances[2][0], 2000); assert.match(lastUrl, /^\/table\/v1\/driving\/-58\.400000,-34\.600000;-58\.300000,-34\.700000;-58\.200000,-34\.800000\?annotations=duration,distance$/);
    const bad = await admin('POST', '/api/ruta/matriz', { puntos: [{ lat: 0, lng: 0 }, { lat: 1, lng: 1 }] }); assert.equal(bad.s, 502);
    TCFG.routingUrl = 'http://127.0.0.1:1'; assert.equal((await admin('POST', '/api/ruta/matriz', { puntos: [{ lat: -34.6, lng: -58.4 }, { lat: -34.7, lng: -58.3 }] })).s, 502);
    TCFG.routingUrl = ''; osrm.close();
  });
  await t('cliente NO ve equipos ni check lists', async () => { for (const p of ['equipos', 'checks']) assert.equal((await cc1('GET', '/api/col?path=' + p)).s, 403, p); });
  await t('solo admin crea equipos; operario y chofer los leen', async () => {
    assert.equal((await put(dep, 'equipos/e1', { nombre: 'AE-01', tipo: 'autoelevador' })).s, 403);
    assert.equal((await put(ch1, 'equipos/e1', { nombre: 'AE-01' })).s, 403);
    assert.equal((await put(admin, 'equipos/e1', { nombre: 'AE-01', tipo: 'autoelevador' })).s, 200);
    assert.equal((await list(dep, 'equipos')).length, 1); assert.equal((await list(ch1, 'equipos')).length, 1);
  });
  const CK = (id, por, extra) => Object.assign({ id, equipoId: 'e1', fecha: '2026-11-12', ts: new Date().toISOString(), porId: por, resultado: 'ok', fallas: [] }, extra || {});
  await t('check list: se crea a nombre propio, no se edita ni se borra', async () => {
    assert.equal((await put(dep, 'checks/k1', CK('k1', ids.o1))).s, 200);
    assert.equal((await put(dep, 'checks/k2', CK('k2', ids.d1))).s, 403);                 // a nombre de otro
    assert.equal((await put(dep, 'checks/k1', CK('k1', ids.o1, { resultado: 'fuera' }))).s, 403); // editar uno existente
    assert.equal((await dep('DELETE', '/api/doc?path=checks/k1')).s, 403);
    assert.equal((await put(ch1, 'checks/k3', CK('k3', ids.d1))).s, 200);
    assert.equal((await put(dep, 'checks/k4', { id: 'k4', porId: ids.o1 })).s, 403);       // sin equipo ni fecha
    assert.equal((await list(admin, 'checks')).length, 2);
  });
  await t('admin puede borrar un check list', async () => assert.equal((await admin('DELETE', '/api/doc?path=checks/k3')).s, 200));
  await t('cambiar de chofer a depósito desde la ficha cambia los permisos reales', async () => {
    assert.equal((await put(admin, 'perfiles/' + ids.d2, { rol: 'deposito', nombre: 'Chofer Dos', telefono: '11 5555-0000' })).s, 200);
    assert.equal((await ch2('GET', '/api/col?path=entregas')).s, 403);
    assert.equal((await ch2('GET', '/api/col?path=equipos')).s, 200);
    assert.equal((await put(admin, 'perfiles/' + ids.d2, { rol: 'admin', nombre: 'Chofer Dos', telefono: '11 5555-0000' })).s, 200);          // intento de escalar: se ignora
    assert.equal((await ch2('GET', '/api/users')).s, 403);
    assert.equal((await admin('GET', '/api/doc?path=' + encodeURIComponent('perfiles/' + ids.d2))).j.data.rol, 'deposito');
  });
  await t('renombrar un usuario conserva su ficha', async () => {
    assert.equal((await admin('PATCH', '/api/users/' + ids.d2, { name: 'Chofer Dos Renombrado' })).s, 200);
    const d = (await admin('GET', '/api/doc?path=' + encodeURIComponent('perfiles/' + ids.d2))).j.data; assert.equal(d.telefono, '11 5555-0000'); assert.equal(d.nombre, 'Chofer Dos Renombrado');
  });
  const sidOf = async (e, p) => { const l = await fetch(base + '/api/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: e, password: p }) }); return l.headers.get('set-cookie').match(/sid=([a-f0-9]{64})/)[1]; };
  const adminSid = await sidOf('admin@test.com', 'clave-admin-123');
  const up = (sid, mime, body) => fetch(base + '/api/upload', { method: 'POST', headers: { cookie: 'sid=' + sid, 'content-type': mime, 'x-filename': 'remito.pdf' }, body });
  await t('contacto de tráfico: lo leen cliente y chofer, solo admin lo cambia; el resto de la configuración sigue cerrada', async () => {
    assert.equal((await put(cc1, 'config/trafico', { telefono: '1' })).s, 403);
    assert.equal((await put(ch1, 'config/trafico', { telefono: '1' })).s, 403);
    assert.equal((await put(admin, 'config/trafico', { nombre: 'Tráfico', telefono: '11 5555-0100' })).s, 200);
    assert.equal((await cc1('GET', '/api/doc?path=config/trafico')).j.data.telefono, '11 5555-0100');
    assert.equal((await ch1('GET', '/api/doc?path=config/trafico')).j.exists, true);
    assert.equal((await cc1('GET', '/api/doc?path=config/deposito')).s, 403);
    assert.equal((await dep('GET', '/api/doc?path=config/trafico')).s, 403);
  });
  await t('el chofer no puede leer teléfonos de clientes', async () => { assert.equal((await ch1('GET', '/api/doc?path=' + encodeURIComponent('perfiles/' + ids.c1))).s, 403); assert.equal((await ch1('GET', '/api/col?path=perfiles')).s, 403); });
  await t('el contenido del archivo debe coincidir con su tipo', async () => assert.equal((await up(adminSid, 'application/pdf', '<script>alert(1)</script>')).status, 415));
  let fileUrl;
  await t('archivo de una entrega: lo ve el cliente dueño y el chofer asignado, nadie más', async () => {
    const r = await up(adminSid, 'application/pdf', Buffer.from('%PDF-1.4 remito de prueba')); assert.equal(r.status, 200); fileUrl = (await r.json()).url;
    const e1 = Object.assign(E('e1', 'c1', 'd1'), { remito: { numero: 'R-1', url: fileUrl } });
    assert.equal((await put(admin, 'entregas/e1', e1)).s, 200); assert.equal((await put(admin, `portal/${ids.c1}/entregas/e1`, e1)).s, 200);
    const get = async sid => (await fetch(base + fileUrl, { headers: { cookie: 'sid=' + sid } })).status;
    assert.equal(await get(adminSid), 200);
    assert.equal(await get(await sidOf('c1@t.com', 'otra-clave-nueva-1')), 200);
    assert.equal(await get(await sidOf('d1@t.com', 'clave-larga-d1')), 200);
    assert.equal(await get(await sidOf('o1@t.com', 'clave-larga-o1')), 404);
    assert.equal(await get(await sidOf('d2@t.com', 'clave-larga-d2')), 404);
  });
  await t('registro de actividad: solo admin, con ingresos, altas y borrados', async () => {
    const a = await admin('GET', '/api/audit'); assert.equal(a.s, 200);
    const acts = a.j.map(x => x.action); for (const k of ['ingreso', 'ingreso_fallido', 'usuario_creado', 'cambio_rol', 'borrado']) assert.ok(acts.includes(k), 'falta ' + k);
    assert.equal((await dep('GET', '/api/audit')).s, 403);
  });
  await t('avisos por correo al cliente: programada y en camino', async () => {
    for (let i = 0; i < 30 && mails.length < 2; i++) await new Promise(r => setTimeout(r, 100));
    const ms = mails.map(decode).filter(m => m.to === 'c1@t.com');
    assert.ok(ms.some(m => /programada/i.test(m.subject) && m.body.includes('G-e1')), 'sin aviso de programada');
    assert.ok(ms.some(m => /en camino/i.test(m.subject) && m.body.includes('https://portal.test')), 'sin aviso de en camino');
  });
  await t('un cambio sin cambio de estado no manda correo', async () => {
    await put(admin, 'entregas/e1', Object.assign(E('e1', 'c1', 'd1'), { estado: 'en_camino' })); await new Promise(r => setTimeout(r, 400)); const antes = mails.length; await put(admin, 'entregas/e1', Object.assign(E('e1', 'c1', 'd1'), { estado: 'en_camino', bultos: 9 })); await new Promise(r => setTimeout(r, 400)); assert.equal(mails.length, antes);
  });

  // ---- gestión ampliada: gastos, órdenes, consentimiento, integración, 2FA, recuperación de clave ----
  const dep2 = mk(); await dep2('POST', '/api/login', { email: 'o1@t.com', password: 'clave-larga-o1' });
  const cli = mk(); await cli('POST', '/api/login', { email: 'c1@t.com', password: 'otra-clave-nueva-1' });
  await t('gastos: el chofer carga el suyo pero no lee, edita ni borra; admin sí', async () => {
    const g = { id: 'g1', tipo: 'combustible', importe: 52000, litros: 40, odo: 1000, equipoId: 'e4', porId: ids.d1, fecha: '2026-01-01' };
    assert.equal((await put(ch1, 'gastos/g1', g)).s, 200);
    assert.equal((await put(ch1, 'gastos/g2', Object.assign({}, g, { id: 'g2', porId: ids.d2 }))).s, 403);          // a nombre de otro
    assert.equal((await put(ch1, 'gastos/g3', Object.assign({}, g, { id: 'g3', importe: -5 }))).s, 403);
    assert.equal((await put(ch1, 'gastos/g1', Object.assign({}, g, { importe: 1 }))).s, 403);                        // no se edita
    assert.equal((await ch1('DELETE', '/api/doc?path=gastos/g1')).s, 403);
    assert.equal((await ch1('GET', '/api/col?path=gastos')).s, 403);
    assert.equal((await list(admin, 'gastos')).length, 1);
    assert.equal((await put(admin, 'gastos/g1', Object.assign({}, g, { importe: 53000 }))).s, 200);
    assert.equal((await cli('GET', '/api/col?path=gastos')).s, 403);
  });
  await t('órdenes de trabajo: operarios solo abren, admin gestiona', async () => {
    const o = { id: 'o1', equipoId: 'e1', estado: 'abierta', origen: 'check', titulo: 'Freno' };
    assert.equal((await put(dep2, 'ordenes/o1', o)).s, 200);
    assert.equal((await put(dep2, 'ordenes/o2', Object.assign({}, o, { id: 'o2', estado: 'cerrada' }))).s, 403);
    assert.equal((await put(dep2, 'ordenes/o1', Object.assign({}, o, { estado: 'cerrada' }))).s, 403);
    assert.equal((await dep2('GET', '/api/col?path=ordenes')).s, 403);
    assert.equal((await put(admin, 'ordenes/o1', Object.assign({}, o, { estado: 'cerrada' }))).s, 200);
  });
  await t('listas editables: admin escribe, chofer y depósito leen, cliente no', async () => {
    assert.equal((await put(admin, 'plantillas/camion', { id: 'camion', items: [['a', 'G', 'Texto', 1]] })).s, 200);
    assert.equal((await put(ch1, 'plantillas/camion', { id: 'camion', items: [] })).s, 403);
    assert.equal((await ch1('GET', '/api/col?path=plantillas')).s, 200);
    assert.equal((await dep2('GET', '/api/col?path=plantillas')).s, 200);
    assert.equal((await put(dep2, 'plantillas/camion', { items: [] })).s, 403);
    assert.equal((await cli('GET', '/api/col?path=plantillas')).s, 403);
  });
  await t('consentimiento: cada chofer firma el suyo, no el de otro; admin lo ve', async () => {
    assert.equal((await put(ch1, 'consents/' + ids.d1, { ok: true, ts: new Date().toISOString() })).s, 200);
    assert.equal((await put(ch1, 'consents/' + ids.d2, { ok: true })).s, 403);
    assert.equal((await put(ch1, 'consents/' + ids.d1, { ok: false })).s, 403);
    assert.equal((await ch1('GET', '/api/doc?path=' + encodeURIComponent('consents/' + ids.d1))).j.exists, true);
    assert.equal((await ch1('GET', '/api/col?path=consents')).s, 403);
    assert.equal((await list(admin, 'consents')).length, 1);
  });
  const KEY = { 'x-api-key': 'clave-de-integracion-de-prueba-123' };
  await t('integración: sin clave o con clave mala no entra', async () => {
    assert.equal((await anon('POST', '/api/integracion/entregas', { entregas: [] })).s, 401);
    assert.equal((await anon('POST', '/api/integracion/entregas', { entregas: [] }, { 'x-api-key': 'mala' })).s, 401);
    assert.equal((await anon('GET', '/api/integracion/entregas', undefined, { 'x-api-key': 'x'.repeat(30) })).s, 401);
  });
  await t('integración: alta, actualización por guía y errores por fila', async () => {
    const item = { guia: 'ERP-1', cliente: 'CLIENTE uno', chofer: 'chofer uno', fecha: '2026-12-01', desde: '09:00', hasta: '12:00', direccion: 'Calle 1', bultos: 3, pesoKg: 120, factura: 'A-1', importe: 1000 };
    let r = await anon('POST', '/api/integracion/entregas', { entregas: [item, { guia: 'ERP-2', cliente: 'No existe', fecha: '2026-12-01', direccion: 'x' }, { guia: 'ERP-3', cliente: 'Cliente Uno', fecha: 'ayer', direccion: 'x' }] }, KEY);
    assert.equal(r.s, 200); assert.equal(r.j.creadas, 1); assert.equal(r.j.errores.length, 2);
    const e = (await list(admin, 'entregas')).find(x => x.data.guia === 'ERP-1'); assert.ok(e); assert.equal(e.data.clienteId, ids.c1); assert.equal(e.data.choferId, ids.d1); assert.equal(e.data.orden >= 1, true);
    assert.equal((await list(cli, `portal/${ids.c1}/entregas`)).some(x => x.data.guia === 'ERP-1'), true);
    await put(admin, 'entregas/' + e.id, Object.assign({}, e.data, { estado: 'entregada', pod: { receptor: 'Ana', completa: false, firma: 'data:x', ts: '2026-12-01T12:00:00Z' } }));
    r = await anon('POST', '/api/integracion/entregas', { entregas: [Object.assign({}, item, { bultos: 5, direccion: 'Calle 2' })] }, KEY);
    assert.equal(r.j.actualizadas, 1); assert.equal(r.j.creadas, 0);
    const e2 = (await list(admin, 'entregas')).find(x => x.data.guia === 'ERP-1'); assert.equal(e2.data.bultos, 5); assert.equal(e2.data.estado, 'entregada'); assert.equal(e2.data.pod.receptor, 'Ana');
    const g = await anon('GET', '/api/integracion/entregas?desde=2026-12-01', undefined, KEY); const x = g.j.find(y => y.guia === 'ERP-1');
    assert.equal(x.pod.completa, false); assert.equal(x.pod.conFirma, true); assert.equal(JSON.stringify(x).includes('data:x'), false);
  });
  await t('copia completa de datos: solo admin, sin hashes de clave', async () => {
    assert.equal((await ch1('GET', '/api/export')).s, 403);
    const r = await admin('GET', '/api/export'); assert.equal(r.s, 200); assert.ok(r.j.documentos['gastos/g1']); assert.equal(JSON.stringify(r.j).includes('scrypt'), false); assert.equal(r.j.usuarios.every(u => !('pass' in u)), true);
  });
  const totpLib = require('../lib/totp');
  await t('2FA: se activa con un código válido y después el ingreso lo exige', async () => {
    assert.equal((await admin('POST', '/api/users', { email: 'a2@t.com', name: 'Admin Dos', role: 'admin', password: 'clave-admin-dos-1' })).s, 200);
    const a2 = mk(); assert.equal((await a2('POST', '/api/login', { email: 'a2@t.com', password: 'clave-admin-dos-1' })).s, 200);
    assert.equal((await ch1('POST', '/api/2fa/setup')).s, 403);
    const su = await a2('POST', '/api/2fa/setup'); assert.equal(su.s, 200); assert.match(su.j.uri, /^otpauth:\/\/totp\//);
    assert.equal((await a2('POST', '/api/2fa/enable', { code: '000000' })).s, 400);
    const now = Math.floor(Date.now() / 30000);
    assert.equal((await a2('POST', '/api/2fa/enable', { code: totpLib.hotp(su.j.secret, now) })).s, 200);
    const b = mk();
    let r = await b('POST', '/api/login', { email: 'a2@t.com', password: 'clave-admin-dos-1' }); assert.equal(r.s, 401); assert.equal(r.j.needCode, true);
    assert.equal((await b('GET', '/api/me')).s, 401);
    assert.equal((await b('POST', '/api/login', { email: 'a2@t.com', password: 'clave-admin-dos-1', code: totpLib.hotp(su.j.secret, now) })).s, 401);   // el mismo código no se reutiliza
    assert.equal((await b('POST', '/api/login', { email: 'a2@t.com', password: 'clave-admin-dos-1', code: totpLib.hotp(su.j.secret, now + 1) })).s, 200);
    assert.equal((await b('GET', '/api/me')).s, 200);
    assert.equal((await b('POST', '/api/2fa/disable', { password: 'mala', code: totpLib.hotp(su.j.secret, now + 1) })).s, 400);
  });
  await t('recuperar clave: respuesta igual exista o no, enlace de un solo uso, cierra sesiones', async () => {
    const n0 = mails.length;
    assert.equal((await anon('POST', '/api/forgot', { email: 'noexiste@t.com' })).s, 200);
    assert.equal((await anon('POST', '/api/forgot', { email: 'c1@t.com' })).s, 200);
    for (let i = 0; i < 30 && mails.length <= n0; i++) await new Promise(r => setTimeout(r, 100));
    assert.equal(mails.length, n0 + 1);
    const m = decode(mails[mails.length - 1]); assert.equal(m.to, 'c1@t.com');
    const tok = (m.body.match(/\?reset=([a-f0-9]{64})/) || [])[1]; assert.ok(tok);
    assert.equal((await anon('POST', '/api/reset', { token: tok, password: 'corta' })).s, 400);
    assert.equal((await anon('POST', '/api/reset', { token: 'a'.repeat(64), password: 'nueva-clave-segura-9' })).s, 400);
    assert.equal((await anon('POST', '/api/reset', { token: tok, password: 'nueva-clave-segura-9' })).s, 200);
    assert.equal((await anon('POST', '/api/reset', { token: tok, password: 'otra-clave-segura-9' })).s, 400);
    assert.equal((await cli('GET', '/api/me')).s, 401);
    assert.equal((await anon('POST', '/api/login', { email: 'c1@t.com', password: 'nueva-clave-segura-9' })).s, 200);
  });

  await t('webhook: cada cambio de estado se avisa firmado con HMAC', async () => {
    const crypto = require('node:crypto'), n0 = hooks.length;
    await put(admin, 'entregas/e1', Object.assign(E('e1', 'c1', 'd1'), { estado: 'no_entregada', guia: 'G-e1' }));
    for (let i = 0; i < 30 && hooks.length === n0; i++) await new Promise(r => setTimeout(r, 100));
    assert.equal(hooks.length, n0 + 1);
    const h = hooks[hooks.length - 1], j = JSON.parse(h.body);
    assert.equal(j.evento, 'entrega.estado'); assert.equal(j.data.estado, 'no_entregada');
    assert.equal(h.sig, 'sha256=' + crypto.createHmac('sha256', 'secreto-de-prueba-largo-1').update(h.body).digest('hex'));
    await put(admin, 'entregas/e1', Object.assign(E('e1', 'c1', 'd1'), { estado: 'no_entregada', guia: 'G-e1', bultos: 9 }));
    await new Promise(r => setTimeout(r, 300)); assert.equal(hooks.length, n0 + 1);   // sin cambio de estado no se avisa
  });
  await t('stock por API: suma el kardex por SKU, ubicación y lote', async () => {
    for (const [id, o] of [['k1', { tipo: 'IN', sku: 'S1', ubicacion: '01-01-01', in: 10, out: 0, lote: 'L1', vence: '2027-01-01' }], ['k2', { tipo: 'OUT', sku: 'S1', ubicacion: '01-01-01', in: 0, out: 4, lote: 'L1' }], ['k3', { tipo: 'IN', sku: 'S2', ubicacion: '01-01-02', in: 5, out: 0 }]])
      assert.equal((await put(admin, 'wms/kardex/items/' + id, Object.assign({ id, fecha: '2026-01-01' }, o))).s, 200);
    const r = await anon('GET', '/api/integracion/entregas?stock=1', undefined, KEY);
    assert.equal(r.s, 200); const a = r.j.find(x => x.sku === 'S1'); assert.equal(a.cantidad, 6); assert.equal(a.lote, 'L1'); assert.equal(a.vence, '2027-01-01'); assert.equal(r.j.find(x => x.sku === 'S2').cantidad, 5);
    assert.equal((await anon('GET', '/api/integracion/entregas?stock=1')).s, 401);
  });
  await t('sincronización por diferencias: trae solo lo nuevo y avisa los borrados', async () => {
    const D = q => admin('GET', '/api/col/delta?path=wms%2Fkardex%2Fitems' + q);
    const f = await D(''); assert.equal(f.s, 200); assert.equal(f.j.count, f.j.rows.length); assert.ok(f.j.cursor);
    await new Promise(r => setTimeout(r, 15));
    assert.equal((await put(admin, 'wms/kardex/items/kd1', { id: 'kd1', fecha: '2026-01-02', tipo: 'IN', sku: 'S9', ubicacion: '01:01:01:00', in: 1, out: 0 })).s, 200);
    const d = await D('&since=' + encodeURIComponent(f.j.cursor)); assert.equal(d.s, 200);
    assert.ok(d.j.rows.some(r => r.id === 'kd1')); assert.ok(d.j.rows.length < f.j.rows.length + 1); assert.equal(d.j.count, f.j.count + 1);
    assert.equal((await admin('DELETE', '/api/doc?path=wms%2Fkardex%2Fitems%2Fkd1')).s, 200);
    const e = await D('&since=' + encodeURIComponent(d.j.cursor)); assert.equal(e.j.count, f.j.count);
    assert.equal((await admin('GET', '/api/col/delta?path=entregas')).s, 400);
    assert.equal((await admin('GET', '/api/col/delta?path=wms%2Fkardex%2Fitems&since=x')).s, 400);
    assert.equal((await ch1('GET', '/api/col/delta?path=wms%2Fkardex%2Fitems')).s, 403);
  });
  await t('reglas: el depósito no ve fletes ni tarifas, lee los módulos pero no los cambia', async () => {
    assert.equal((await put(admin, 'wms/fletes/items/f1', { id: 'f1', cobrado: 100 })).s, 200);
    assert.equal((await put(admin, 'wms/cfgx/items/main', { id: 'main', mods: ['ped'] })).s, 200);
    assert.equal((await dep('GET', '/api/col?path=wms%2Ffletes%2Fitems')).s, 403);
    assert.equal((await dep('GET', '/api/col?path=wms%2Ftransportistas%2Fitems')).s, 403);
    assert.equal((await dep('GET', '/api/col?path=wms%2Fcfgx%2Fitems')).s, 200);
    assert.equal((await put(dep, 'wms/cfgx/items/main', { id: 'main', mods: [] })).s, 403);
    assert.equal((await put(dep, 'wms/pedidos/items/PED-000900', { id: 'PED-000900', estado: 'borrador' })).s, 200);
    assert.equal((await put(dep, 'wms/alertas/items/a1', { id: 'a1' })).s, 403);
  });
  await t('API de pedidos del ERP: crea en borrador, es idempotente y valida', async () => {
    assert.equal((await put(admin, 'wms/skus/items/S1', { id: 'S1', codigo: 'S1', producto: 'Uno' })).s, 200);
    const P = (b) => anon('POST', '/api/integracion/pedidos', b, KEY);
    assert.equal((await anon('POST', '/api/integracion/pedidos', { pedidos: [] })).s, 401);
    const ok = { ref: 'ERP-1', cliente: 'Cliente ERP', direccion: 'Calle 1', fecha: '2026-12-01', lineas: [{ sku: 'S1', cantidad: 3 }] };
    const r = await P({ pedidos: [ok, { ref: 'ERP-2', cliente: 'X', lineas: [{ sku: 'NOEXISTE', cantidad: 1 }] }, { cliente: 'X', lineas: [] }] });
    assert.equal(r.s, 200); assert.equal(r.j.creados, 1); assert.equal(r.j.errores.length, 2);
    const r2 = await P({ pedidos: [Object.assign({}, ok, { lineas: [{ sku: 'S1', cantidad: 5 }] })] });
    assert.equal(r2.j.creados, 0); assert.equal(r2.j.actualizados, 1);
    const g = await anon('GET', '/api/integracion/pedidos', undefined, KEY); assert.equal(g.s, 200);
    const x = g.j.find(p => p.ref === 'ERP-1'); assert.equal(x.estado, 'borrador'); assert.equal(g.j.filter(p => p.ref === 'ERP-1').length, 1);
    const id = x.id; const doc = (await admin('GET', '/api/doc?path=' + encodeURIComponent('wms/pedidos/items/' + id))).j.data; assert.equal(doc.lineas[0].qty, 5);
    assert.equal((await put(admin, 'wms/pedidos/items/' + id, Object.assign({}, doc, { estado: 'reservado' }))).s, 200);
    assert.equal((await P({ pedidos: [ok] })).j.errores.length, 1);
  });
  await t('copia y restauración: lo restaurado es idéntico y pasa la verificación', async () => {
    const { execFileSync } = require('node:child_process'), { DatabaseSync } = require('node:sqlite');
    const bdir = fs.mkdtempSync(path.join(os.tmpdir(), 'bk-')), rdir = fs.mkdtempSync(path.join(os.tmpdir(), 'rs-'));
    const env = Object.assign({}, process.env, { DATA_DIR: dir, BACKUP_DIR: bdir });
    execFileSync(process.execPath, ['--disable-warning=ExperimentalWarning', path.join(__dirname, '..', 'scripts', 'backup.js')], { env });
    const f = fs.readdirSync(bdir).find(x => /^portal-.*\.db$/.test(x)); assert.ok(f);
    const out = execFileSync(process.execPath, ['--disable-warning=ExperimentalWarning', path.join(__dirname, '..', 'scripts', 'restore.js'), path.join(bdir, f), rdir]).toString();
    assert.match(out, /Restaurada: \d+ usuarios/);
    const a = new DatabaseSync(path.join(dir, 'portal.db'), { readOnly: true }), b = new DatabaseSync(path.join(rdir, 'portal.db'), { readOnly: true });
    const sum = d => d.prepare('SELECT COUNT(*) c, SUM(LENGTH(data)) l FROM docs').get(); assert.deepEqual(sum(b), sum(a));
    assert.equal(b.prepare('SELECT COUNT(*) c FROM users').get().c, a.prepare('SELECT COUNT(*) c FROM users').get().c);
    a.close(); b.close();
    fs.writeFileSync(path.join(bdir, 'malo.db'), 'esto no es una base');
    assert.throws(() => execFileSync(process.execPath, ['--disable-warning=ExperimentalWarning', path.join(__dirname, '..', 'scripts', 'restore.js'), path.join(bdir, 'malo.db'), rdir], { stdio: 'pipe' }));
  });

  console.log(`\n${pass} pruebas correctas` + (process.exitCode ? ' — HAY FALLAS' : ''));
  server.close(); smtp.close(); process.exit(process.exitCode || 0);
}
