'use strict';
// Prueba de desastre: crea datos reales (usuarios, entregas, un archivo subido), hace la copia, destruye todo,
// restaura en una carpeta nueva con el script oficial, levanta el servidor de nuevo y verifica que no se perdió nada.
// Uso: npm run test:dr
const assert = require('node:assert/strict');
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');
const { createServer } = require('../server');
const root = path.join(__dirname, '..'), node = [process.execPath, '--disable-warning=ExperimentalWarning'];

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'dr-'));
const cfgFor = dir => ({ port: 0, dataDir: dir, companyName: 'DR', adminEmail: 'a@dr.com', adminPassword: 'clave-de-prueba-12', cookieSecure: false, trustProxy: false, baseUrl: '', integrationKey: '', rateLimit: 1e9, webhookUrl: '', webhookSecret: '', backupDir: path.join(tmp, 'bk'), smtp: null });
const start = async dir => { fs.mkdirSync(dir, { recursive: true }); const s = createServer(cfgFor(dir)); await new Promise(r => s.server.listen(0, r)); return { s, base: 'http://127.0.0.1:' + s.server.address().port }; };
const client = base => { let sid = ''; return async (m, u, b, h) => { const r = await fetch(base + u, { method: m, headers: Object.assign({ cookie: sid ? 'sid=' + sid : '', 'content-type': 'application/json' }, h), body: b === undefined ? undefined : (Buffer.isBuffer(b) ? b : JSON.stringify(b)) }); const c = r.headers.get('set-cookie'), mm = c && c.match(/sid=([^;]+)/); if (mm) sid = mm[1]; const buf = Buffer.from(await r.arrayBuffer()); let j = null; try { j = JSON.parse(buf.toString()); } catch (_) {} return { s: r.status, j, buf }; }; };
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAFUlEQVR42mP8z8BQz0AEYBxVSF+FABJADveWkH6oAAAAAElFTkSuQmCC', 'base64');
let n = 0; const ok = m => console.log('  ok  ' + m);

(async () => {
  const dirA = path.join(tmp, 'a'), dirB = path.join(tmp, 'b');
  // 1) producción
  let { s, base } = await start(dirA); let A = client(base);
  assert.equal((await A('POST', '/api/login', { email: 'a@dr.com', password: 'clave-de-prueba-12' })).s, 200);
  const cl = (await A('POST', '/api/users', { email: 'c@dr.com', name: 'Cliente DR', role: 'cliente', password: 'clave-cliente-dr-1' })).j.id;
  const ch = (await A('POST', '/api/users', { email: 'ch@dr.com', name: 'Chofer DR', role: 'chofer', password: 'clave-chofer-dr-12' })).j.id;
  for (let i = 1; i <= 25; i++) assert.equal((await A('PUT', '/api/doc?path=entregas/e' + i, { id: 'e' + i, guia: 'G-' + i, clienteId: cl, cliente: 'Cliente DR', choferId: ch, estado: i % 3 ? 'programada' : 'entregada', fecha: '2026-11-12', direccion: 'Calle ' + i })).s, 200);
  const up = await A('POST', '/api/upload', PNG, { 'content-type': 'image/png', 'x-filename': 'foto.png' }); assert.equal(up.s, 200);
  const sumA = crypto.createHash('sha256').update(PNG).digest('hex');
  ok('datos de producción creados (2 usuarios, 25 entregas, 1 foto)');
  // 2) copia con el script oficial, con el servidor funcionando
  const env = Object.assign({}, process.env, { DATA_DIR: dirA, BACKUP_DIR: path.join(tmp, 'bk') });
  execFileSync(node[0], [node[1], path.join(root, 'scripts', 'backup.js')], { env });
  const f = fs.readdirSync(path.join(tmp, 'bk')).find(x => /^portal-.*\.db$/.test(x)); assert.ok(f);
  ok('copia hecha con el servidor en uso: ' + f);
  // 3) desastre: se pierde la carpeta de datos completa
  s.server.closeAllConnections && s.server.closeAllConnections(); await new Promise(r => s.server.close(r)); s.db && s.db.close && s.db.close();
  fs.rmSync(dirA, { recursive: true, force: true });
  assert.ok(!fs.existsSync(dirA)); ok('desastre simulado: carpeta de datos borrada');
  // 4) restauración en carpeta nueva
  const out = execFileSync(node[0], [node[1], path.join(root, 'scripts', 'restore.js'), path.join(tmp, 'bk', f), dirB]).toString();
  assert.match(out, /Restaurada: 3 usuarios/); assert.match(out, /Archivos subidos restaurados/); ok(out.trim());
  // 5) servidor nuevo sobre lo restaurado
  ({ s, base } = await start(dirB)); A = client(base);
  assert.equal((await A('POST', '/api/login', { email: 'a@dr.com', password: 'clave-de-prueba-12' })).s, 200); ok('el administrador entra con su clave de antes');
  const ent = (await A('GET', '/api/col?path=entregas')).j; assert.equal(ent.length, 25); assert.equal(ent.filter(e => e.data.estado === 'entregada').length, 8); ok('las 25 entregas y sus estados están intactas');
  const C = client(base); assert.equal((await C('POST', '/api/login', { email: 'ch@dr.com', password: 'clave-chofer-dr-12' })).s, 200); ok('el chofer entra con su clave de antes');
  const foto = await A('GET', up.j.url); assert.equal(foto.s, 200); assert.equal(crypto.createHash('sha256').update(foto.buf).digest('hex'), sumA); ok('la foto subida se sirve idéntica byte a byte');
  assert.equal((await client(base)('GET', up.j.url)).s, 401); ok('la foto sigue protegida: sin sesión no se ve');
  assert.equal((await A('PUT', '/api/doc?path=entregas/e99', { id: 'e99', guia: 'G-99', clienteId: cl, cliente: 'Cliente DR', choferId: ch, estado: 'programada', fecha: '2026-11-13', direccion: 'Nueva' })).s, 200); ok('y el sistema sigue aceptando datos nuevos');
  console.log('\nRecuperación verificada: nada se perdió.');
  s.server.closeAllConnections && s.server.closeAllConnections(); s.server.close(); fs.rmSync(tmp, { recursive: true, force: true }); process.exit(0);
})().catch(e => { console.error('FALLA:', e.message); process.exit(1); });
