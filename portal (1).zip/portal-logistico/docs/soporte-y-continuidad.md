# Soporte, niveles de servicio y continuidad

> Plantilla para completar con lo que realmente podés cumplir. Prometer menos y cumplir es mejor que lo contrario.

## Soporte
| | Compromiso |
|---|---|
| Canal | [WhatsApp / correo / teléfono] |
| Horario | [Lunes a viernes de 8 a 18 h] |
| Primera respuesta | [4 horas hábiles] |
| Falla que impide entregar | [Atención el mismo día hábil] |
| Consulta o mejora | [Respuesta en 2 días hábiles] |

## Qué pasa si el servidor falla
- El chofer puede seguir trabajando **sin conexión**: los cambios se guardan en el teléfono y se envían al volver la señal.
- Hay una **copia diaria** de la base de datos y los archivos (automática con Docker o con `npm run clientes`; si no, programala con cron). Restaurar lleva [N] horas con el procedimiento del README.
- Se recomienda probar la restauración **una vez** antes de empezar a operar.

## Continuidad del servicio (qué pasa si yo dejo de prestarlo)
- La empresa es dueña de sus datos y puede descargar **una copia completa** (administración → Gestión → Datos y seguridad).
- El portal corre en el servidor de la empresa y no depende de servicios de terceros para funcionar: puede seguir funcionando aunque yo deje de prestar el servicio.
- [Opcional] Acuerdo de continuidad: entrega del código y de las instrucciones a un tercero designado por la empresa.

## Mantenimiento
- Actualizaciones de seguridad: [mensual / cuando hay una vulnerabilidad conocida].
- Cambios de versión se avisan con [3] días de anticipación y se prueban antes en una copia.

## Seguridad básica que ya incluye
Ingreso con límite de intentos, verificación en dos pasos para administración, recuperación de contraseña por correo, permisos por rol aplicados en el servidor, registro de actividad y archivos protegidos.
**Lo que no incluye:** auditoría de seguridad externa, certificaciones ni monitoreo 24/7.
