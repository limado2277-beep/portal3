# Acuerdo de continuidad (borrador para que revise un abogado)

Entre **[Proveedor]** y **[Empresa]**. Fecha: [__].

1. **Propiedad de los datos.** Todos los datos cargados o generados (entregas, clientes, stock, pruebas de entrega) son de la Empresa. El Proveedor no los usa para otro fin ni los comparte.
2. **Exportación.** La Empresa puede descargar una copia completa en cualquier momento (Gestión › Datos y seguridad) y el Proveedor la entrega en formato abierto (JSON/CSV) dentro de [5] días hábiles si se la pide.
3. **Código en custodia.** El Proveedor entrega a la Empresa el código fuente completo y la documentación (README, `docs/`, runbook) en [un repositorio de la Empresa / un depósito en custodia con un tercero]. Si el Proveedor deja de prestar el servicio o no atiende un incidente grave en [N] días, la Empresa puede usar, modificar y operar ese código internamente.
4. **Contacto técnico alternativo.** La Empresa o el Proveedor designan a [Nombre, contacto] con acceso al código y al procedimiento de restauración. Se hace un simulacro de restauración cada [6] meses.
5. **Niveles de servicio.** Los de `soporte-y-continuidad.md`.
6. **Prueba piloto y salida sin costo.** Piloto de 30 días con un depósito y 3 o 4 choferes. Se mide antes y durante: OTIF, reclamos por entrega y check lists realizados. Si no mejora lo acordado ([ej.: OTIF +__ puntos]), la Empresa lo da de baja **sin costo** y se le entregan sus datos (punto 2).
7. **Confidencialidad y seguridad.** Claves y accesos de la Empresa no se comparten; incidentes de seguridad se avisan en [24] h.
8. **Cambios de alcance** (ERP, nuevas funciones) se acuerdan por escrito, con precio.

Firmas: ______________________  ______________________
