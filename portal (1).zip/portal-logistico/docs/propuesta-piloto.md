# Propuesta de piloto — Portal de entregas y depósito

> Plantilla para completar. Todo lo que está entre [corchetes] se reemplaza con datos reales. Los números del ejemplo son ilustrativos, no promesas.

## Qué problema resolvemos
- Saber en tiempo real en qué estado está cada entrega, sin llamadas ni planillas cruzadas.
- Dejar **prueba de entrega** (quién recibió, firma, foto, ubicación) para evitar reclamos.
- Medir el servicio con números: **OTIF**, causas de no entrega, uso de la flota, costo por entrega y por km.
- Mantener los equipos en condiciones: check list diario, órdenes de trabajo y service por km u horas.
- Ordenar el depósito: lotes y vencimientos (FEFO), conteos cíclicos, picking por ubicación.

## Alcance del piloto ([30] días)
| Incluye | No incluye |
|---|---|
| [N] choferes y [N] operarios de depósito | Integración a medida con sistemas que no tengan exportación a Excel/CSV |
| Hasta [N] clientes con acceso a su portal | Hardware (celulares, impresoras) |
| Carga de entregas por Excel/CSV o API | Seguimiento GPS continuo (no se ofrece) |
| Capacitación de [2] horas + soporte por [canal] | Asesoramiento legal o de higiene y seguridad |

## Cómo se trabaja
1. **Semana 1:** cargamos clientes, choferes, equipos y las listas de control de la empresa.
2. **Semanas 2 a 4:** operación real en paralelo con lo que ya usan. Reunión corta semanal para ajustar.
3. **Cierre:** informe de indicadores del piloto y decisión conjunta de seguir o no.

## Qué medimos para decidir
| Indicador | Punto de partida | Meta del piloto |
|---|---|---|
| OTIF (a tiempo y completo) | [medir en la semana 1] | [+X puntos] |
| Entregas con prueba (firma/foto) | [0%] | [90%+] |
| Reclamos por "no recibí" | [N por mes] | [reducir a la mitad] |
| Check lists diarios hechos | [N%] | [95%+] |
| Tiempo en armar la hoja de ruta | [N min] | [reducir] |

## Condiciones
- Precio del piloto: [$ / gratis]. Precio posterior: [$ por mes, por usuario o por entrega].
- Los datos son de la empresa y puede llevárselos en cualquier momento (copia completa en un clic).
- Detalle de datos personales y ubicación: ver *política de datos*. Soporte y continuidad: ver *soporte y continuidad*.
