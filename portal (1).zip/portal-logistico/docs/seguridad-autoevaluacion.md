# Seguridad: autoevaluación (no es una auditoría)

**Importante:** esto lo revisó quien desarrolló el portal. **No hubo auditoría externa ni prueba de penetración.** Si la empresa lo exige, hay que contratarla antes de operar con datos reales.

## Qué está hecho (y cómo se probó)
| Tema | Medida | Prueba |
|---|---|---|
| Claves | scrypt con sal, largo mínimo, rechazo de claves comunes | prueba automática |
| Sesiones | cookie HttpOnly, SameSite, `Secure` con HTTPS, cierre de sesiones al cambiar la clave | prueba automática |
| Fuerza bruta | 8 intentos por 15 min por IP y correo; límite general por IP | prueba automática |
| Permisos | las reglas se aplican **en el servidor** por rol (cliente, chofer, depósito, admin); un chofer solo ve sus entregas | 60 pruebas automáticas incluyen accesos denegados |
| Verificación en dos pasos | TOTP (RFC 6238) con código de un solo uso | prueba automática |
| Inyección de HTML (XSS) | todo texto se escapa al dibujar; CSP restrictiva | prueba en navegador: nombres con `<img onerror>` y `<svg onload>` en clientes, guías, SKUs, OC, equipos y devoluciones recorriendo todas las pantallas: **0 ejecuciones** |
| CSRF | verificación de `Origin` en escrituras | prueba automática |
| SQL | consultas parametrizadas | revisión de código |
| Integración | clave comparada en tiempo constante; webhooks firmados con HMAC | prueba automática |
| Datos | copia y restauración probadas (verificación de integridad) | prueba automática |

## Lo que NO está verificado
- Auditoría o pentest externo.
- Cabeceras y TLS reales de tu dominio (dependen de cómo lo publiques: probá con un escáner como SSL Labs).
- Que el correo (SMTP) real funcione: probado solo con un servidor falso.
- Docker y Caddy: escritos pero no ejecutados en un servidor real.
- Dependencias: el proyecto no usa paquetes externos, lo que reduce la superficie, pero Node y el sistema operativo se actualizan por tu cuenta.

## Datos personales y ubicación
La ubicación del chofer se toma solo al confirmar una entrega y con su consentimiento registrado. La política (para que Legal y RR. HH. revisen) está en `politica-datos-y-ubicacion.md`. La ley argentina de protección de datos personales (25.326) y el registro ante la autoridad de aplicación los tiene que evaluar un abogado: este documento no es asesoramiento legal.
