# Implementación llave en mano

Servicio para que la empresa arranque el lunes con todo cargado y probado. Es el ingreso fuerte del negocio: la suscripción mensual puede ser baja.

## Qué incluye (alcance cerrado, completar con números)
- Relevamiento previo y limpieza de los Excel que mande la empresa.
- Hasta **[X] SKUs, [Y] ubicaciones, [Z] vehículos y [W] usuarios**. Lo que exceda se cotiza aparte.
- Conteo físico del stock y acta firmada por la empresa (hasta [N] horas de conteo).
- Alta de usuarios, vehículos con sus vencimientos y primer check list de cada uno.
- Etiquetado de ubicaciones (la impresión y el papel/etiquetas los pone la empresa).
- Capacitación de choferes y de depósito con sus propios teléfonos.
- Simulacro de una entrega completa y acompañamiento del primer día.
- **Fuera de alcance:** integración con el ERP, hardware (lectores, impresoras), obra de racks, cambios a medida.

## Antes de ir (una semana)
1. Reunión de relevamiento; definí quién de la empresa decide y firma el acta.
2. Mandales las plantillas (Gestión › Puesta en marcha: usuarios, vehículos, conteo, y el Excel de depósito).
3. Armá la instancia: `npm run alta-cliente -- --nombre "..." --dominio portal.empresa.com.ar --admin dueno@empresa.com.ar`, apuntá el DNS y levantá con `npm run clientes`.
4. Cargá lo que ya mandaron y revisá "Lunes OK" para ver qué falta.
5. Pedí que ordenen el depósito y dejen los vehículos accesibles.

## Semana de implementación
| Día | Tarea | Resultado |
|---|---|---|
| Jueves | Conteo físico, etiquetado | Archivo de conteo completo |
| Viernes por la mañana | Cargar conteo: revisar diferencias, aplicar, imprimir acta | Acta firmada |
| Viernes por la tarde | Altas masivas, vehículos, check lists, entregas del lunes, consentimientos de ubicación | Lunes OK sin rojos |
| Sábado | Simulacro de punta a punta con un chofer | Problemas corregidos |
| Lunes | Acompañamiento, medición del primer día | Informe de arranque |

## Criterio de "listo"
La pantalla **Gestión › Lunes OK** sin controles rojos: datos cargados, saldo inicial y acta, check list de cada vehículo, consentimientos, entregas programadas, administración con verificación en dos pasos, https y copia de seguridad hecha.

## Cómo se cobra (estructura; los montos los definís vos)
- **Implementación:** pago único, 50 % al aceptar y 50 % al arrancar. Dolarizado o indexado.
- **Mensual:** por chofer activo con un mínimo por empresa; incluye servidor, copias, actualizaciones y soporte según `soporte-y-continuidad.md`.
- Piloto de 30 días y condiciones de salida según `acuerdo-de-continuidad.md`.
- Cada hora extra de conteo o de limpieza de datos fuera del tope se cobra aparte.

## Lo que hay que dejar por escrito
- Que cargás los datos que la empresa entrega y no garantizás el stock más allá del acta de conteo.
- Quién es el contacto de la empresa y quién firma el acta.
- Qué se les entrega al terminar: acceso de administración, copia de los datos, plantillas y este documento de arranque.
- Que las claves temporales se cambian el primer día.

## Cuidados
- No uses datos ni procesos de tu empleador en ningún cliente. Revisá tu contrato por exclusividad y conflicto de intereses antes de vender.
- Facturación (monotributo u otra figura) y tratamiento de datos de ubicación: consultalo con un contador y un abogado.
- No sos auditor: tu conteo es un servicio operativo, no una auditoría de stock.
