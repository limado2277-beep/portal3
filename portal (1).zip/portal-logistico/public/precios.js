(function () {
  function txt(id, t) { var e = document.getElementById(id); if (e) e.textContent = t; }
  fetch('/comercial.json').then(function (r) { return r.ok ? r.json() : {}; }).catch(function () { return {}; }).then(function (c) {
    c = c || {};
    if (typeof c.precio_mensual === 'number' && c.precio_mensual > 0) {
      txt('precio', new Intl.NumberFormat('es-AR', { style: 'currency', currency: c.moneda || 'ARS', maximumFractionDigits: 0 }).format(c.precio_mensual) + ' por mes');
    }
    txt('nota', c.nota_precio || '');
    var cta = document.getElementById('cta'), n = String(c.whatsapp || '').replace(/\D/g, '');
    var dias = Number(c.prueba_dias) > 0 ? Number(c.prueba_dias) : 0;
    if (n.length >= 8) {
      var a = document.createElement('a'); a.className = 'btn pri'; a.target = '_blank'; a.rel = 'noopener';
      a.textContent = dias ? 'Pedir prueba gratis de ' + dias + ' días' : 'Hablar por WhatsApp';
      a.href = 'https://wa.me/' + n + '?text=' + encodeURIComponent('Hola, quiero probar el Portal Logístico.');
      cta.appendChild(a);
    } else if (c.email) {
      var m = document.createElement('a'); m.className = 'btn pri'; m.textContent = dias ? 'Pedir prueba gratis de ' + dias + ' días' : 'Escribinos';
      m.href = 'mailto:' + encodeURIComponent(c.email).replace('%40', '@'); cta.appendChild(m);
    }
  });
})();
